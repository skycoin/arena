package services

func Add(num1, num2 float64) float64 {
	return num1 + num2
}
